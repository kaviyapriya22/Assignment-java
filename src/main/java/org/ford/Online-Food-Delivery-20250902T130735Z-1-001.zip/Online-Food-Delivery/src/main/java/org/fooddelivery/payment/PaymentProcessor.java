package org.fooddelivery.payment;

public interface PaymentProcessor {

    public void processPayment(double amount);
}
