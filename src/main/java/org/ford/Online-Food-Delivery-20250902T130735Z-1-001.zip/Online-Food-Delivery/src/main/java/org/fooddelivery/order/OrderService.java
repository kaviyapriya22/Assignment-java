package org.fooddelivery.order;

public interface OrderService {

    public void placeOrder(String item,double price);

}
