package org.fooddelivery.notification;

public interface NotificationService {

    public void sendNotification(String message);
}
